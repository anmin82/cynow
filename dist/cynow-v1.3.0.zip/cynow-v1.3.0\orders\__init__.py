"""
CYNOW 수주(PO) 관리 앱

FCMS 연계를 위한 수주 입력, 번호 예약, 매칭 검증, 진행 모니터링 기능 제공
"""

default_app_config = 'orders.apps.OrdersConfig'

