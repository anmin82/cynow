from django.apps import AppConfig


class CylindersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cylinders'
