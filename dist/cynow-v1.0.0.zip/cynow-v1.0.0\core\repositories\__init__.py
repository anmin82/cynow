# Repository pattern for VIEW access

